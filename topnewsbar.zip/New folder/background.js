// 定期実行の設定（30分ごとにニュースや天気を更新）
chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create('fetchDataAlarm', { periodInMinutes: 30 });
  fetchAllData();
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'fetchDataAlarm') {
    fetchAllData();
  }
});

// メッセージ受信（手動更新や設定変更時）
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'FORCE_REFRESH_DATA') {
    fetchAllData().then(() => {
      // 各タブにデータ更新を通知
      broadcastToTabs({ type: 'DATA_UPDATED' });
    });
  }
});

// すべてのデータを取得してストレージに保存するメイン関数
async function fetchAllData() {
  try {
    const data = await chrome.storage.local.get({
      my_news_bar_source: 'domestic',
      my_news_bar_region: '130000' // デフォルト：東京都
    });

    const source = data.my_news_bar_source;
    const regionCode = data.my_news_bar_region;

    let newsList = [];
    let weatherData = { title: '【天気】 取得失敗', link: 'https://www.jma.go.jp/bosai/forecast/' };

    // 1. 天気データの常時取得（左側に常駐させるため）
    try {
      weatherData = await fetchWeather(regionCode);
    } catch (e) {
      console.error('天気データの取得に失敗しました:', e);
    }

    // 2. 選択されたコンテンツに応じたデータ取得
    if (source === 'weather') {
      // 天気のみの場合、ニュース枠にも天気の詳細や別情報を入れるか、天気タイトルを設定
      newsList = [
        { title: weatherData.title, link: weatherData.link },
        { title: '【お知らせ】 天気予報モードで表示中です', link: 'https://www.jma.go.jp/bosai/forecast/' }
      ];
    } else if (source === 'stocks') {
      // 為替レートの取得
      newsList = await fetchExchangeRates();
    } else {
      // ニュースの取得（domestic, foreign, all）
      newsList = await fetchNews(source);
    }

    // ストレージにキャッシュとして保存
    await chrome.storage.local.set({
      cachedNews: newsList,
      cachedWeather: weatherData
    });

  } catch (error) {
    console.error('fetchAllData エラー:', error);
  }
}

// ニュースをRSSから取得する関数
async function fetchNews(sourceType) {
  let rssUrls = [];

  const domesticUrls = [
    'https://www.nhk.or.jp/rss/news/cat0.xml', // NHK 主要ニュース
    'https://news.yahoo.co.jp/rss/topics/top-picks.xml' // Yahoo!トピックス
  ];

  const foreignUrls = [
    'https://feeds.bbci.co.uk/news/rss.xml', // BBC
    'https://rss.cnn.com/rss/edition.rss' // CNN
  ];

  if (sourceType === 'domestic') {
    rssUrls = domesticUrls;
  } else if (sourceType === 'foreign') {
    rssUrls = foreignUrls;
  } else if (sourceType === 'all') {
    rssUrls = [...domesticUrls, ...foreignUrls];
  }

  let allItems = [];

  for (const url of rssUrls) {
    try {
      // api.rss2json.com を使ってJSONに変換して取得
      const apiUrl = `https://api.rss2json.com/v1/api.json?rss_url=${encodeURIComponent(url)}`;
      const res = await fetch(apiUrl);
      const json = await res.json();

      if (json.status === 'ok' && json.items) {
        const items = json.items.map(item => ({
          title: item.title,
          link: item.link
        }));
        allItems = allItems.concat(items);
      }
    } catch (e) {
      console.error(`RSS取得失敗 (${url}):`, e);
    }
  }

  // 取得できたアイテムがない場合のフォールバック
  if (allItems.length === 0) {
    allItems = [{ title: 'ニュースの取得に失敗しました', link: '#' }];
  }

  return allItems;
}

// 気象庁APIから天気予報を取得する関数
async function fetchWeather(regionCode) {
  const url = `https://www.jma.go.jp/bosai/forecast/data/forecast/${regionCode}.json`;
  const res = await fetch(url);
  const data = await res.json();

  // 気象庁JSONの構造から今日の天気概況や Weather を抽出
  const officeName = data[0].publishingOffice;
  const timeSeries = data[0].timeSeries[0];
  const area = timeSeries.areas[0];
  const weatherCodes = area.weathers; // 天気文言の配列

  let currentWeather = weatherCodes && weatherCodes.length > 0 ? weatherCodes[0] : '情報なし';
  // 改行や余分なスペースを整理
  currentWeather = currentWeather.replace(/\s+/g, ' ');

  return {
    title: `【天気】 ${currentWeather}`,
    link: `https://www.jma.go.jp/bosai/forecast/#area_type=offices&area_code=${regionCode}`
  };
}

// 為替レートを Frankfurter API から取得する関数
async function fetchExchangeRates() {
  try {
    const res = await fetch('https://api.frankfurter.app/latest?from=USD&to=JPY,EUR,GBP');
    const data = await res.json();

    if (data && data.rates) {
      const usdJpy = data.rates.JPY ? data.rates.JPY.toFixed(2) : '---';
      const eurUsd = data.rates.EUR ? (1 / data.rates.EUR).toFixed(2) : '---'; // 簡易的な目安として
      return [
        { title: `💱 ドル/円 (USD/JPY): ${usdJpy} 円`, link: 'https://m.finance.yahoo.co.jp/stocks/detail?code=USDTPY=X' },
        { title: `💱 ユーロ/ドル (EUR/USD): ${eurUsd}`, link: 'https://m.finance.yahoo.co.jp/stocks/detail?code=EURUSD=X' }
      ];
    }
  } catch (e) {
    console.error('為替取得失敗:', e);
  }

  return [
    { title: '為替レートの取得に失敗しました', link: '#' }
  ];
}

// 開いているすべてのタブにメッセージを送信する補助関数
function broadcastToTabs(message) {
  chrome.tabs.query({}, (tabs) => {
    tabs.forEach((tab) => {
      if (tab.id) {
        chrome.tabs.sendMessage(tab.id, message).catch(() => {});
      }
    });
  });
}