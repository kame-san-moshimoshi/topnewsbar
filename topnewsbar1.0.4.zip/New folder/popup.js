document.addEventListener('DOMContentLoaded', () => {
  const regionElem = document.getElementById('weather-region-select');
  const alignElem = document.getElementById('news-align-select');
  const themeElem = document.getElementById('news-theme-select');
  const scrollElem = document.getElementById('news-scroll-select');
  const statusMsg = document.getElementById('status-msg');

  const updateContainer = document.getElementById('update-container');
  const updateMsg = document.getElementById('update-msg');
  const updateBtn = document.getElementById('update-btn');

  // 初期値の読み込み
  chrome.storage.local.get({
    my_news_bar_sources: ['yahoo_top'],
    my_news_bar_region: '130000',
    my_news_bar_align: 'left',
    my_news_bar_theme: 'normal',
    my_news_bar_scroll: 'on'
  }, (data) => {
    regionElem.value = data.my_news_bar_region;
    alignElem.value = data.my_news_bar_align;
    themeElem.value = data.my_news_bar_theme;
    scrollElem.value = data.my_news_bar_scroll;

    // チェックボックスの状態を復元
    const checkboxes = document.querySelectorAll('input[name="news_source"]');
    checkboxes.forEach(cb => {
      if (data.my_news_bar_sources.includes(cb.value)) {
        cb.checked = true;
      }
    });

    if (data.hasUpdate) {
      if (updateMsg) {
        updateMsg.textContent = `🚀 v${data.latestVersion} が利用可能です！`;
      }
      if (updateContainer) {
        updateContainer.style.display = 'block';
      }
    }
  });

  chrome.runtime.sendMessage({ type: 'CHECK_FOR_UPDATES' });

  if (updateBtn) {
    updateBtn.addEventListener('click', () => {
      chrome.tabs.create({ url: 'https://github.com/kame-san-moshimoshi/topnewsbar' });
    });
  }

  // チェックボックス変更時の処理
  const checkboxes = document.querySelectorAll('input[name="news_source"]');
  checkboxes.forEach(cb => {
    cb.addEventListener('change', () => {
      const selectedSources = Array.from(checkboxes)
        .filter(i => i.checked)
        .map(i => i.value);

      chrome.storage.local.set({ my_news_bar_sources: selectedSources }, () => {
        showStatus();
        chrome.runtime.sendMessage({ type: 'FORCE_REFRESH_DATA' });
      });
    });
  });

  regionElem.addEventListener('change', (e) => {
    const selectedRegion = e.target.value;
    chrome.storage.local.set({ my_news_bar_region: selectedRegion }, () => {
      showStatus();
      chrome.runtime.sendMessage({ type: 'FORCE_REFRESH_DATA' });
    });
  });

  alignElem.addEventListener('change', (e) => {
    const selectedAlign = e.target.value;
    chrome.storage.local.set({ my_news_bar_align: selectedAlign }, () => {
      showStatus();
      broadcastToTabs({ type: 'UPDATE_NEWS_ALIGN', align: selectedAlign });
    });
  });

  themeElem.addEventListener('change', (e) => {
    const selectedTheme = e.target.value;
    chrome.storage.local.set({ my_news_bar_theme: selectedTheme }, () => {
      showStatus();
      broadcastToTabs({ type: 'UPDATE_NEWS_THEME', theme: selectedTheme });
    });
  });

  scrollElem.addEventListener('change', (e) => {
    const selectedScroll = e.target.value;
    chrome.storage.local.set({ my_news_bar_scroll: selectedScroll }, () => {
      showStatus();
      broadcastToTabs({ type: 'UPDATE_NEWS_SCROLL', scroll: selectedScroll });
    });
  });

  function showStatus() {
    statusMsg.textContent = '保存しました！';
    setTimeout(() => {
      statusMsg.textContent = '';
    }, 1500);
  }

  function broadcastToTabs(message) {
    chrome.tabs.query({}, (tabs) => {
      tabs.forEach((tab) => {
        if (tab.id) {
          chrome.tabs.sendMessage(tab.id, message).catch(() => {});
        }
      });
    });
  }
});