// GitHub上の最新 manifest.json の URL
const GITHUB_MANIFEST_URL = 'https://raw.githubusercontent.com/kame-san-moshimoshi/topnewsbar/main/manifest.json';

// 定期実行の設定（30分ごとにニュースや天気、6時間ごとに更新確認）
chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create('fetchDataAlarm', { periodInMinutes: 30 });
  chrome.alarms.create('checkUpdateAlarm', { periodInMinutes: 360 });
  fetchAllData();
  checkForUpdates();
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'fetchDataAlarm') {
    fetchAllData();
  } else if (alarm.name === 'checkUpdateAlarm') {
    checkForUpdates();
  }
});

// メッセージ受信（手動更新や設定変更時）
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'FORCE_REFRESH_DATA') {
    fetchAllData().then(() => {
      broadcastToTabs({ type: 'DATA_UPDATED' });
    });
  } else if (message.type === 'CHECK_FOR_UPDATES') {
    checkForUpdates();
  }
});

// 現在のバージョンを記録・確認する関数
async function checkForUpdates() {
  try {
    const manifest = chrome.runtime.getManifest();
    const currentVersion = manifest.version;

    const response = await fetch(`${GITHUB_MANIFEST_URL}?t=${Date.now()}`);
    if (!response.ok) {
      throw new Error(`GitHubからのバージョン取得に失敗しました: ${response.status}`);
    }
    
    const remoteData = await response.json();
    const remoteVersion = remoteData.version;

    console.log(`現在のバージョン: ${currentVersion}, 最新バージョン: ${remoteVersion}`);

    if (compareVersions(remoteVersion, currentVersion) > 0) {
      console.log('新しいアップデートがあります！');
      await chrome.storage.local.set({ 
        hasUpdate: true, 
        latestVersion: remoteVersion 
      });
      broadcastToTabs({ 
        type: 'NEW_VERSION_AVAILABLE', 
        version: remoteVersion 
      });
    } else {
      await chrome.storage.local.set({ hasUpdate: false });
    }
  } catch (error) {
    console.error('アップデート確認エラー:', error);
  }
}

// バージョン文字列を比較するヘルパー関数
function compareVersions(v1, v2) {
  const parts1 = v1.split('.').map(Number);
  const parts2 = v2.split('.').map(Number);
  
  for (let i = 0; i < Math.max(parts1.length, parts2.length); i++) {
    const p1 = parts1[i] || 0;
    const p2 = parts2[i] || 0;
    if (p1 > p2) return 1;
    if (p1 < p2) return -1;
  }
  return 0;
}

// すべてのデータを取得してストレージに保存するメイン関数
async function fetchAllData() {
  try {
    const data = await chrome.storage.local.get({
      my_news_bar_sources: ['yahoo_top'],
      my_news_bar_region: '130000'
    });

    const sources = data.my_news_bar_sources;
    const regionCode = data.my_news_bar_region;

    let newsList = [];
    let weatherData = { title: '【天気】 取得失敗', link: 'https://www.jma.go.jp/bosai/forecast/' };

    try {
      weatherData = await fetchWeather(regionCode);
    } catch (e) {
      console.error('天気データの取得に失敗しました:', e);
    }

    for (const source of sources) {
      if (source === 'weather') {
        newsList.push({ title: weatherData.title, link: weatherData.link });
      } else if (source === 'stocks') {
        const rates = await fetchExchangeRates();
        newsList.push(...rates);
      } else {
        const items = await fetchNews(source);
        newsList.push(...items);
      }
    }

    if (newsList.length === 0) {
      newsList = [{ title: '表示するコンテンツが選択されていません', link: '#' }];
    }

    await chrome.storage.local.set({
      cachedNews: newsList,
      cachedWeather: weatherData
    });

  } catch (error) {
    console.error('fetchAllData エラー:', error);
  }
}

async function fetchNews(sourceType) {
  const nhkRssMap = {
    'yahoo_top': ['https://news.yahoo.co.jp/rss/topics/top-picks.xml'],
    'domestic': ['https://news.yahoo.co.jp/rss/topics/top-picks.xml'],
    'nhk_main': ['https://www.nhk.or.jp/rss/news/cat0.xml'],
    'nhk_syokai': ['https://www.nhk.or.jp/rss/news/cat1.xml'],
    'nhk_bunka': ['https://www.nhk.or.jp/rss/news/cat2.xml'],
    'nhk_kagaku': ['https://www.nhk.or.jp/rss/news/cat3.xml'],
    'nhk_seiji': ['https://www.nhk.or.jp/rss/news/cat4.xml'],
    'nhk_keizai': ['https://www.nhk.or.jp/rss/news/cat5.xml'],
    'nhk_kokusai': ['https://www.nhk.or.jp/rss/news/cat6.xml'],
    'nhk_sports': ['https://www.nhk.or.jp/rss/news/cat7.xml']
  };

  const rssUrls = nhkRssMap[sourceType] || [];
  let allItems = [];

  for (const url of rssUrls) {
    try {
      const res = await fetch(url);
      const text = await res.text();
      const itemMatches = text.match(/<item>([\s\S]*?)<\/item>/g) || [];

      itemMatches.forEach(itemStr => {
        const titleMatch = itemStr.match(/<title>(?:<!\[CDATA\[)?([\s\S]*?)(?:\]\]>)?<\/title>/);
        const linkMatch = itemStr.match(/<link>(?:<!\[CDATA\[)?([\s\S]*?)(?:\]\]>)?<\/link>/);

        if (titleMatch && linkMatch) {
          let title = titleMatch[1].trim();
          let link = linkMatch[1].trim();
          title = title.replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>');
          allItems.push({ title, link });
        }
      });
    } catch (e) {
      console.error(`RSS取得失敗 (${url}):`, e);
    }
  }

  return allItems;
}

async function fetchWeather(regionCode) {
  const url = `https://www.jma.go.jp/bosai/forecast/data/forecast/${regionCode}.json`;
  const res = await fetch(url);
  const data = await res.json();

  const timeSeries = data[0].timeSeries[0];
  const area = timeSeries.areas[0];
  const weatherCodes = area.weathers;

  let currentWeather = weatherCodes && weatherCodes.length > 0 ? weatherCodes[0] : '情報なし';
  currentWeather = currentWeather.replace(/\s+/g, ' ');

  return {
    title: `【天気】 ${currentWeather}`,
    link: `https://www.jma.go.jp/bosai/forecast/#area_type=offices&area_code=${regionCode}`
  };
}

async function fetchExchangeRates() {
  try {
    const res = await fetch('https://api.frankfurter.app/latest?from=USD&to=JPY,EUR,GBP');
    const data = await res.json();

    if (data && data.rates) {
      const usdJpy = data.rates.JPY ? data.rates.JPY.toFixed(2) : '---';
      const eurUsd = data.rates.EUR ? (1 / data.rates.EUR).toFixed(2) : '---';
      return [
        { title: `💱 ドル/円 (USD/JPY): ${usdJpy} 円`, link: 'https://m.finance.yahoo.co.jp/stocks/detail?code=USDTPY=X' },
        { title: `💱 ユーロ/ドル (EUR/USD): ${eurUsd}`, link: 'https://m.finance.yahoo.co.jp/stocks/detail?code=EURUSD=X' }
      ];
    }
  } catch (e) {
    console.error('為替取得失敗:', e);
  }

  return [{ title: '為替レートの取得に失敗しました', link: '#' }];
}

function broadcastToTabs(message) {
  chrome.tabs.query({}, (tabs) => {
    tabs.forEach((tab) => {
      if (tab.id) {
        chrome.tabs.sendMessage(tab.id, message).catch(() => {});
      }
    });
  });
}