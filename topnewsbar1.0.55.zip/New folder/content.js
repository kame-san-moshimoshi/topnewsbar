const FONT_SIZES = {
  small: '12px',
  medium: '14px',
  large: '16px'
};

let newsBar = null;
let showBtn = null;
let newsList = [];
let currentIndex = 0;
let timer = null;
let isInitialized = false;
let isScrollNavEnabled = true; // スクロール切り替えの有効状態
let isScrolling = false; // 連続スクロール制御用のフラグ
let particleTimer = null; // エフェクト（雨・雪）生成用タイマー
let newsDisplayStyle = 'fade'; // 'fade' または 'marquee' (追加)

function updateBarVisibility(isHidden, position = 'top') {
  if (!newsBar || !showBtn) return;

  // 位置クラスを更新
  newsBar.classList.remove('pos-top', 'pos-bottom', 'pos-left', 'pos-right');
  newsBar.classList.add(`pos-${position}`);

  // body要素の余白用クラスを更新
  document.body.classList.remove(
    'news-bar-active-top',
    'news-bar-active-bottom',
    'news-bar-active-left',
    'news-bar-active-right'
  );

  if (isHidden) {
    newsBar.classList.add('news-hidden');
    showBtn.style.display = 'flex';
  } else {
    newsBar.classList.remove('news-hidden');
    document.body.classList.add(`news-bar-active-${position}`);
    showBtn.style.display = 'none';
  }
}

async function applyTheme(themeName) {
  if (!newsBar) return;

  // 既存のテーマクラスをすべて削除
  newsBar.classList.remove(
    'theme-emergency',
    'theme-halloween',
    'theme-christmas',
    'theme-spring',
    'theme-rainy',
    'theme-summer'
  );

  // 既存のパーティクル（雪・雨）をクリア
  if (particleTimer) {
    clearInterval(particleTimer);
    particleTimer = null;
  }
  newsBar.querySelectorAll('.news-particle').forEach(el => el.remove());

  // ユーザーが手動で「緊急地震速報風」にしている場合はそちらを優先
  if (themeName === 'emergency') {
    newsBar.classList.add('theme-emergency');
    return;
  }

  // --- 日付取得（開発者モードの設定を確認） ---
  const devData = await chrome.storage.local.get({
    dev_mode: 'off',
    dev_month: '10',
    dev_day: '31'
  });

  let month, day;

  if (devData.dev_mode === 'on') {
    // 開発者モード有効時は指定された月日を使用
    month = parseInt(devData.dev_month, 10);
    day = parseInt(devData.dev_day, 10);
  } else {
    // 通常時は実際の現在日時を使用
    const now = new Date();
    month = now.getMonth() + 1; // 1〜12月
    day = now.getDate();        // 1〜31日
  }

  let activeTheme = themeName;

  // --- 自動季節判定ロジック ---
  if (month === 10 && day === 31) {
    // 10月31日：ハロウィン仕様
    newsBar.classList.add('theme-halloween');
  } else if (month === 12 && (day === 24 || day === 25)) {
    // 12月24・25日：クリスマス仕様
    newsBar.classList.add('theme-christmas');
    activeTheme = 'christmas';
  } else if (month >= 3 && month <= 4) {
    // 3〜4月一杯：ピンクカラー（春）
    newsBar.classList.add('theme-spring');
  } else if (month === 6) {
    // 6月：雨降る仕様
    newsBar.classList.add('theme-rainy');
    activeTheme = 'rainy';
  } else if (month === 7 || month === 8) {
    // 7〜8月：水色カラー（夏）
    newsBar.classList.add('theme-summer');
  } else {
    // それ以外の期間（設定された通常テーマを適用）
    if (themeName && themeName !== 'normal') {
      newsBar.classList.add(`theme-${themeName}`);
    }
  }

  // クリスマス（雪）または6月（雨）の場合、ランダム生成を開始
  if (activeTheme === 'christmas' || activeTheme === 'rainy') {
    startParticles(activeTheme === 'christmas' ? 'snow' : 'rain');
  }
}

// ランダムに雪や雨を降らせる処理
function startParticles(type) {
  const characters = type === 'snow' ? ['❄', '❅', '❆', '･'] : ['｜', '|'];

  particleTimer = setInterval(() => {
    if (!newsBar || !newsBar.classList.contains(`theme-${type === 'snow' ? 'christmas' : 'rainy'}`)) {
      return;
    }

    const particle = document.createElement('span');
    particle.className = 'news-particle';
    particle.textContent = characters[Math.floor(Math.random() * characters.length)];

    // 横位置、アニメーション速度、揺れ幅、サイズ、透明度を完全にランダム化
    const leftPos = Math.random() * newsBar.offsetWidth;
    const duration = 1.5 + Math.random() * 2.5; // 1.5秒〜4秒
    const drift = (Math.random() - 0.5) * 20; // 左右に不規則に揺らす
    const fontSize = type === 'snow' ? (9 + Math.random() * 8) : (11 + Math.random() * 4);

    particle.style.left = `${leftPos}px`;
    particle.style.fontSize = `${fontSize}px`;
    particle.style.animationDuration = `${duration}s`;
    particle.style.setProperty('--drift', `${drift}px`);

    if (type === 'snow') {
      particle.style.color = `rgba(255, 255, 255, ${0.4 + Math.random() * 0.5})`;
    } else {
      particle.style.color = `rgba(129, 236, 236, ${0.3 + Math.random() * 0.4})`;
    }

    newsBar.appendChild(particle);

    // 落下完了後に要素を削除
    setTimeout(() => {
      particle.remove();
    }, duration * 1000);
  }, 180); // 180ミリ秒ごとにランダムなタイミングで粒を生成
}

// スクロール切り替え設定の更新
function updateScrollNavSetting(scrollSetting) {
  isScrollNavEnabled = (scrollSetting !== 'off');
}

// スクロール操作でニュースを切り替えるリスナー
function initScrollNavigation() {
  if (!newsBar) return;

  newsBar.addEventListener('wheel', (e) => {
    if (!isScrollNavEnabled) return;
    if (newsList.length <= 1) return;

    // バー上でのWebページ全体のスクロール動作を防ぐ
    e.preventDefault();

    // 連続でホイールが回されたときの過剰な高速スキップを防ぐ
    if (isScrolling) return;
    isScrolling = true;

    if (e.deltaY > 0) {
      // 下方向へのスクロール -> 次のニュース
      currentIndex = (currentIndex + 1) % newsList.length;
    } else {
      // 上方向へのスクロール -> 前のニュース
      currentIndex = (currentIndex - 1 + newsList.length) % newsList.length;
    }

    displayCurrentNews();
    resetTimer();

    // 一定時間（250ミリ秒）経過するまで次のスクロール入力を受け付けない
    setTimeout(() => {
      isScrolling = false;
    }, 250);

  }, { passive: false });
}

function initUI() {
  if (document.getElementById('my-news-bar')) return;

  newsBar = document.createElement('div');
  newsBar.id = 'my-news-bar';
  newsBar.innerHTML = `
    <span class="news-prefix" id="news-prefix-label">速報</span>
    <div class="news-content-area">
      <span class="news-content" id="news-text-span">読み込み中...</span>
    </div>
    <div class="news-controls">
      <button id="news-prev-btn" title="前へ">◀</button>
      <button id="news-next-btn" title="次へ">▶</button>
      <button id="news-refresh-btn" title="更新">🔄</button>
      <button class="font-size-btn" data-size="small">小</button>
      <button class="font-size-btn" data-size="medium">中</button>
      <button class="font-size-btn" data-size="large">大</button>
      <button id="news-hide-btn" title="非表示">×</button>
    </div>
  `;
  document.body.appendChild(newsBar);

  showBtn = document.createElement('button');
  showBtn.id = 'my-news-show-btn';
  showBtn.innerHTML = '▲ バーを表示';
  document.body.appendChild(showBtn);

  // スクロール切り替え機能の初期化
  initScrollNavigation();

  // 「バーを表示」ボタンのドラッグ移動ロジック
  let isDragging = false;
  let startX, startY;
  let initialLeft, initialTop;

  showBtn.addEventListener('mousedown', (e) => {
    isDragging = true;
    startX = e.clientX;
    startY = e.clientY;

    const rect = showBtn.getBoundingClientRect();
    initialLeft = rect.left;
    initialTop = rect.top;

    showBtn.style.right = 'auto';
    showBtn.style.bottom = 'auto';
    showBtn.style.left = `${initialLeft}px`;
    showBtn.style.top = `${initialTop}px`;

    e.preventDefault();
  });

  document.addEventListener('mousemove', (e) => {
    if (!isDragging) return;
    const dx = e.clientX - startX;
    const dy = e.clientY - startY;

    let newLeft = initialLeft + dx;
    let newTop = initialTop + dy;

    newLeft = Math.max(0, Math.min(window.innerWidth - showBtn.offsetWidth, newLeft));
    newTop = Math.max(0, Math.min(window.innerHeight - showBtn.offsetHeight, newTop));

    showBtn.style.left = `${newLeft}px`;
    showBtn.style.top = `${newTop}px`;
  });

  document.addEventListener('mouseup', () => {
    if (!isDragging) return;
    isDragging = false;

    const rect = showBtn.getBoundingClientRect();
    chrome.storage.local.set({
      my_news_bar_btn_left: `${rect.left}px`,
      my_news_bar_btn_top: `${rect.top}px`
    });
  });

  showBtn.addEventListener('click', () => {
    chrome.storage.local.set({ my_news_bar_hidden: 'false' });
    chrome.storage.local.get({ my_news_bar_position: 'top' }, (data) => {
      updateBarVisibility(false, data.my_news_bar_position);
    });
  });

  const hideBtn = document.getElementById('news-hide-btn');
  if (hideBtn) {
    hideBtn.addEventListener('click', () => {
      chrome.storage.local.set({ my_news_bar_hidden: 'true' });
      chrome.storage.local.get({ my_news_bar_position: 'top' }, (data) => {
        updateBarVisibility(true, data.my_news_bar_position);
      });
    });
  }

  const prevBtn = document.getElementById('news-prev-btn');
  if (prevBtn) {
    prevBtn.addEventListener('click', () => {
      if (newsList.length <= 1) return;
      currentIndex = (currentIndex - 1 + newsList.length) % newsList.length;
      displayCurrentNews();
      resetTimer();
    });
  }

  const nextBtn = document.getElementById('news-next-btn');
  if (nextBtn) {
    nextBtn.addEventListener('click', () => {
      if (newsList.length <= 1) return;
      currentIndex = (currentIndex + 1) % newsList.length;
      displayCurrentNews();
      resetTimer();
    });
  }

  const refreshBtn = document.getElementById('news-refresh-btn');
  if (refreshBtn) {
    refreshBtn.addEventListener('click', () => {
      const textSpan = document.getElementById('news-text-span');
      if (textSpan) textSpan.textContent = '更新中...';
      chrome.runtime.sendMessage({ type: 'FORCE_REFRESH_DATA' });
    });
  }

  document.querySelectorAll('.font-size-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const sizeKey = e.target.getAttribute('data-size');
      chrome.storage.local.set({ my_news_bar_font_size: sizeKey });
      newsBar.style.setProperty('--news-font-size', FONT_SIZES[sizeKey]);

      document.querySelectorAll('.font-size-btn').forEach(b => b.classList.remove('active'));
      e.target.classList.add('active');

      resetTimer();
    });
  });

  isInitialized = true;
}

function displayCurrentNews() {
  const span = document.getElementById('news-text-span');
  const area = document.querySelector('.news-content-area');
  if (!span || !area || newsList.length === 0) return;

  // 「常時横流れ（marquee）」モードの場合の処理（修正版）
  if (newsDisplayStyle === 'marquee') {
    const rawText = newsList.map(item => `  💬 ${item.title}`).join(' *** ');
    const combinedText = `${rawText}   ***   ${rawText}`; // 2回繰り返してきれいにループさせる
    
    span.innerHTML = `<a href="${newsList[currentIndex].link}" target="_blank" rel="noopener noreferrer">${combinedText}</a>`;
    
    span.classList.remove('news-fade-out');
    span.classList.remove('news-marquee');

    requestAnimationFrame(() => {
      const singleTextWidth = span.offsetWidth / 2; // 半分の幅（1周分の幅）
      const duration = Math.max(singleTextWidth / 50, 10); // 速度調整
      
      span.style.setProperty('--scroll-amount', `-${singleTextWidth}px`);
      span.style.animationDuration = `${duration}s`;
      span.classList.add('news-marquee');
    });
    return;
  }

  // --- 従来のフェード切り替え処理 ---
  span.classList.add('news-fade-out');
  setTimeout(() => {
    const item = newsList[currentIndex];
    span.innerHTML = `<a href="${item.link}" target="_blank" rel="noopener noreferrer">${item.title}</a>`;
    span.classList.remove('news-fade-out');
    span.classList.remove('news-marquee');
    span.style.removeProperty('--scroll-amount');

    requestAnimationFrame(() => {
      const textWidth = span.offsetWidth;
      const areaWidth = area.offsetWidth;

      if (textWidth > areaWidth) {
        const diff = textWidth - areaWidth + 30;
        span.style.setProperty('--scroll-amount', `-${diff}px`);
        const duration = Math.max(diff / 40, 6);
        span.style.animationDuration = `${duration}s`;
        span.classList.add('news-marquee');
      }
    });
  }, 300);
}

function autoSlide() {
  if (newsList.length <= 1) return;
  currentIndex = (currentIndex + 1) % newsList.length;
  displayCurrentNews();
}

function resetTimer() {
  if (timer) clearInterval(timer);
  if (newsList.length > 1 && newsDisplayStyle !== 'marquee') {
    timer = setInterval(autoSlide, 30000);
  }
}

// ストレージからキャッシュデータを読み込んで画面に反映する
async function loadBarData() {
  if (!isInitialized) {
    initUI();
  }

  try {
    const data = await chrome.storage.local.get({
      my_news_bar_source: 'domestic',
      my_news_bar_hidden: 'false',
      my_news_bar_position: 'top',
      my_news_bar_font_size: 'medium',
      my_news_bar_align: 'left',
      my_news_bar_style: 'fade', // 追加
      my_news_bar_theme: 'normal',
      my_news_bar_scroll: 'on',
      my_news_bar_sources: ['yahoo_top', 'weather'],
      my_news_bar_btn_left: '',
      my_news_bar_btn_top: '',
      cachedNews: []
    });

    newsDisplayStyle = data.my_news_bar_style; // 追加

    // サイトごとのカスタム表示切替
    const currentUrl = window.location.href;
    let activeNewsList = data.cachedNews;

    if (currentUrl.includes('sites.google.com/view/aam32bit')) {
      activeNewsList = [{ title: ' 使ってくれてありがとう！/Thank You For Using!', link: '#' }];
    } else if (currentUrl.includes('youtube.com/@aam32bit')) {
      activeNewsList = [{ title: ' お,YouTubeみてくれるんだ～', link: '#' }];
    } else if (currentUrl.includes('https://github.com/kame-san-moshimoshi/topnewsbar')) {
      activeNewsList = [{ title: ' 更新、ご迷惑おかけします。', link: '#' }];
    }

    // 設定からスクロール切り替えの有効状態を反映
    updateScrollNavSetting(data.my_news_bar_scroll);

    if (showBtn && data.my_news_bar_btn_left && data.my_news_bar_btn_top) {
      showBtn.style.right = 'auto';
      showBtn.style.top = data.my_news_bar_btn_top;
      showBtn.style.left = data.my_news_bar_btn_left;
    }

    newsBar.style.setProperty('--news-font-size', FONT_SIZES[data.my_news_bar_font_size] || '14px');
    newsBar.style.setProperty('--news-align', data.my_news_bar_align);
    await applyTheme(data.my_news_bar_theme);

    const prefixLabel = document.getElementById('news-prefix-label');
    if (prefixLabel) {
      if (data.my_news_bar_sources.length === 1 && data.my_news_bar_sources[0] === 'stocks') {
        prefixLabel.textContent = '為替';
      } else {
        prefixLabel.textContent = '速報';
      }
    }

    document.querySelectorAll('.font-size-btn').forEach(btn => {
      if (btn.getAttribute('data-size') === data.my_news_bar_font_size) {
        btn.classList.add('active');
      } else {
        btn.classList.remove('active');
      }
    });

    updateBarVisibility(data.my_news_bar_hidden === 'true', data.my_news_bar_position);

    newsList = activeNewsList;
    if (newsList.length === 0) {
      newsList = [{ title: 'データを読み込み中...', link: '#' }];
    }
    currentIndex = 0;
    displayCurrentNews();
    resetTimer();

  } catch (error) {
    console.error('データの表示に失敗しました:', error);
  }
}

// バックグラウンドやポップアップからの変更通知を受け取る
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'UPDATE_NEWS_SOURCE' || message.type === 'UPDATE_WEATHER_REGION' || message.type === 'DATA_UPDATED') {
    loadBarData();
  } else if (message.type === 'UPDATE_NEWS_POSITION') {
    chrome.storage.local.get({ my_news_bar_hidden: 'false' }, (data) => {
      updateBarVisibility(data.my_news_bar_hidden === 'true', message.position);
    });
  } else if (message.type === 'UPDATE_NEWS_ALIGN') {
    if (newsBar) {
      newsBar.style.setProperty('--news-align', message.align);
    }
  } else if (message.type === 'UPDATE_NEWS_STYLE') { // 追加
    newsDisplayStyle = message.style;
    displayCurrentNews();
    resetTimer();
  } else if (message.type === 'UPDATE_NEWS_THEME') {
    applyTheme(message.theme);
  } else if (message.type === 'UPDATE_NEWS_SCROLL') {
    updateScrollNavSetting(message.scroll);
  } else if (message.type === 'UPDATE_DEV_MODE') {
    chrome.storage.local.get({ my_news_bar_theme: 'normal' }, (data) => {
      applyTheme(data.my_news_bar_theme);
    });
  }
});

// 初回読み込み
loadBarData();