// 定期実行の設定（30分ごとにニュースや天気を更新）
chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create('fetchDataAlarm', { periodInMinutes: 30 });
  fetchAllData();
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'fetchDataAlarm') {
    fetchAllData();
  }
});

// メッセージ受信（手動更新や設定変更時）
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'FORCE_REFRESH_DATA') {
    fetchAllData().then(() => {
      broadcastToTabs({ type: 'DATA_UPDATED' });
    });
  }
});

// すべてのデータを取得してストレージに保存するメイン関数
async function fetchAllData() {
  try {
    const data = await chrome.storage.local.get({
      my_news_bar_source: 'domestic',
      my_news_bar_region: '130000' // デフォルト：東京都
    });

    const source = data.my_news_bar_source;
    const regionCode = data.my_news_bar_region;

    let newsList = [];
    let weatherData = { title: '【天気】 取得失敗', link: 'https://www.jma.go.jp/bosai/forecast/' };

    // 1. 天気データの常時取得
    try {
      weatherData = await fetchWeather(regionCode);
    } catch (e) {
      console.error('天気データの取得に失敗しました:', e);
    }

    // 2. 選択されたコンテンツに応じたデータ取得
    if (source === 'weather') {
      newsList = [
        { title: weatherData.title, link: weatherData.link },
        { title: '【お知らせ】 天気予報モードで表示中です', link: 'https://www.jma.go.jp/bosai/forecast/' }
      ];
    } else if (source === 'stocks') {
      newsList = await fetchExchangeRates();
    } else {
      newsList = await fetchNews(source);
    }

    // ストレージにキャッシュとして保存
    await chrome.storage.local.set({
      cachedNews: newsList,
      cachedWeather: weatherData
    });

  } catch (error) {
    console.error('fetchAllData エラー:', error);
  }
}

// ニュースをRSS（XML）から正規表現で安全に抽出する関数（Service Worker対応）
async function fetchNews(sourceType) {
  let rssUrls = [];

  const domesticUrls = [
    'https://news.yahoo.co.jp/rss/topics/top-picks.xml'
  ];

  const foreignUrls = [
    'https://feeds.bbci.co.uk/news/rss.xml',
    'https://rss.cnn.com/rss/edition.rss'
  ];

  if (sourceType === 'domestic') {
    rssUrls = domesticUrls;
  } else if (sourceType === 'foreign') {
    rssUrls = foreignUrls;
  } else if (sourceType === 'all') {
    rssUrls = [...domesticUrls, ...foreignUrls];
  }

  let allItems = [];

  for (const url of rssUrls) {
    try {
      const res = await fetch(url);
      const text = await res.text();

      // 正規表現で <item> タグごとに分割
      const itemMatches = text.match(/<item>([\s\S]*?)<\/item>/g) || [];

      itemMatches.forEach(itemStr => {
        // タイトルの抽出（CDATAセクションや通常のタグに対応）
        const titleMatch = itemStr.match(/<title>(?:<!\[CDATA\[)?([\s\S]*?)(?:\]\]>)?<\/title>/);
        // リンクの抽出
        const linkMatch = itemStr.match(/<link>(?:<!\[CDATA\[)?([\s\S]*?)(?:\]\]>)?<\/link>/);

        if (titleMatch && linkMatch) {
          let title = titleMatch[1].trim();
          let link = linkMatch[1].trim();
          
          // HTMLエンティティの簡易置換（必要に応じて）
          title = title.replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>');

          allItems.push({ title, link });
        }
      });
    } catch (e) {
      console.error(`RSS取得失敗 (${url}):`, e);
    }
  }

  if (allItems.length === 0) {
    allItems = [{ title: 'ニュースの取得に失敗しました', link: '#' }];
  }

  return allItems;
}

// 気象庁APIから天気予報を取得する関数
async function fetchWeather(regionCode) {
  const url = `https://www.jma.go.jp/bosai/forecast/data/forecast/${regionCode}.json`;
  const res = await fetch(url);
  const data = await res.json();

  const timeSeries = data[0].timeSeries[0];
  const area = timeSeries.areas[0];
  const weatherCodes = area.weathers;

  let currentWeather = weatherCodes && weatherCodes.length > 0 ? weatherCodes[0] : '情報なし';
  currentWeather = currentWeather.replace(/\s+/g, ' ');

  return {
    title: `【天気】 ${currentWeather}`,
    link: `https://www.jma.go.jp/bosai/forecast/#area_type=offices&area_code=${regionCode}`
  };
}

// 為替レートを Frankfurter API から取得する関数
async function fetchExchangeRates() {
  try {
    const res = await fetch('https://api.frankfurter.app/latest?from=USD&to=JPY,EUR,GBP');
    const data = await res.json();

    if (data && data.rates) {
      const usdJpy = data.rates.JPY ? data.rates.JPY.toFixed(2) : '---';
      const eurUsd = data.rates.EUR ? (1 / data.rates.EUR).toFixed(2) : '---';
      return [
        { title: `💱 ドル/円 (USD/JPY): ${usdJpy} 円`, link: 'https://m.finance.yahoo.co.jp/stocks/detail?code=USDTPY=X' },
        { title: `💱 ユーロ/ドル (EUR/USD): ${eurUsd}`, link: 'https://m.finance.yahoo.co.jp/stocks/detail?code=EURUSD=X' }
      ];
    }
  } catch (e) {
    console.error('為替取得失敗:', e);
  }

  return [
    { title: '為替レートの取得に失敗しました', link: '#' }
  ];
}

// 開いているすべてのタブにメッセージを送信する補助関数
function broadcastToTabs(message) {
  chrome.tabs.query({}, (tabs) => {
    tabs.forEach((tab) => {
      if (tab.id) {
        chrome.tabs.sendMessage(tab.id, message).catch(() => {});
      }
    });
  });
}