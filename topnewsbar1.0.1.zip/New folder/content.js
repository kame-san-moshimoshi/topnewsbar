const FONT_SIZES = {
  small: '12px',
  medium: '14px',
  large: '16px'
};

let newsBar = null;
let showBtn = null;
let newsList = [];
let currentIndex = 0;
let timer = null;
let isInitialized = false;

function updateBarVisibility(isHidden) {
  if (!newsBar || !showBtn) return;

  if (isHidden) {
    newsBar.classList.add('news-hidden');
    document.body.classList.remove('news-bar-active');
    showBtn.style.display = 'flex';
  } else {
    newsBar.classList.remove('news-hidden');
    document.body.classList.add('news-bar-active');
    showBtn.style.display = 'none';
  }
}

function applyTheme(themeName) {
  if (!newsBar) return;
  if (themeName === 'emergency') {
    newsBar.classList.add('theme-emergency');
  } else {
    newsBar.classList.remove('theme-emergency');
  }
}

function initUI() {
  if (document.getElementById('my-news-bar')) return;

  newsBar = document.createElement('div');
  newsBar.id = 'my-news-bar';
  newsBar.innerHTML = `
    <div class="news-weather-fixed" id="news-weather-container">
      <span class="weather-prefix">天気</span>
      <span id="weather-text-span">取得中...</span>
    </div>
    <span class="news-prefix" id="news-prefix-label">速報</span>
    <div class="news-content-area">
      <span class="news-content" id="news-text-span">読み込み中...</span>
    </div>
    <div class="news-controls">
      <button id="news-prev-btn" title="前へ">◀</button>
      <button id="news-next-btn" title="次へ">▶</button>
      <button id="news-refresh-btn" title="更新">🔄</button>
      <button class="font-size-btn" data-size="small">小</button>
      <button class="font-size-btn" data-size="medium">中</button>
      <button class="font-size-btn" data-size="large">大</button>
      <button id="news-hide-btn" title="非表示">×</button>
    </div>
  `;
  document.body.appendChild(newsBar);

  showBtn = document.createElement('button');
  showBtn.id = 'my-news-show-btn';
  showBtn.innerHTML = '▲ バーを表示';
  document.body.appendChild(showBtn);

  // --- 「バーを表示」ボタンのドラッグ移動ロジック ---
  let isDragging = false;
  let startX, startY;
  let initialLeft, initialTop;

  showBtn.addEventListener('mousedown', (e) => {
    isDragging = true;
    startX = e.clientX;
    startY = e.clientY;

    const rect = showBtn.getBoundingClientRect();
    initialLeft = rect.left;
    initialTop = rect.top;

    // right基準を解除してleft/topに切り替え
    showBtn.style.right = 'auto';
    showBtn.style.bottom = 'auto';
    showBtn.style.left = `${initialLeft}px`;
    showBtn.style.top = `${initialTop}px`;

    e.preventDefault();
  });

  document.addEventListener('mousemove', (e) => {
    if (!isDragging) return;
    const dx = e.clientX - startX;
    const dy = e.clientY - startY;

    let newLeft = initialLeft + dx;
    let newTop = initialTop + dy;

    // 画面外に行き過ぎないように制限
    newLeft = Math.max(0, Math.min(window.innerWidth - showBtn.offsetWidth, newLeft));
    newTop = Math.max(0, Math.min(window.innerHeight - showBtn.offsetHeight, newTop));

    showBtn.style.left = `${newLeft}px`;
    showBtn.style.top = `${newTop}px`;
  });

  document.addEventListener('mouseup', () => {
    if (!isDragging) return;
    isDragging = false;

    // 位置をストレージに保存
    const rect = showBtn.getBoundingClientRect();
    chrome.storage.local.set({
      my_news_bar_btn_left: `${rect.left}px`,
      my_news_bar_btn_top: `${rect.top}px`
    });
  });
  // ----------------------------------------------

  showBtn.addEventListener('click', () => {
    chrome.storage.local.set({ my_news_bar_hidden: 'false' });
    updateBarVisibility(false);
  });

  const hideBtn = document.getElementById('news-hide-btn');
  if (hideBtn) {
    hideBtn.addEventListener('click', () => {
      chrome.storage.local.set({ my_news_bar_hidden: 'true' });
      updateBarVisibility(true);
    });
  }

  const prevBtn = document.getElementById('news-prev-btn');
  if (prevBtn) {
    prevBtn.addEventListener('click', () => {
      if (newsList.length <= 1) return;
      currentIndex = (currentIndex - 1 + newsList.length) % newsList.length;
      displayCurrentNews();
      resetTimer();
    });
  }

  const nextBtn = document.getElementById('news-next-btn');
  if (nextBtn) {
    nextBtn.addEventListener('click', () => {
      if (newsList.length <= 1) return;
      currentIndex = (currentIndex + 1) % newsList.length;
      displayCurrentNews();
      resetTimer();
    });
  }

  const refreshBtn = document.getElementById('news-refresh-btn');
  if (refreshBtn) {
    refreshBtn.addEventListener('click', () => {
      const textSpan = document.getElementById('news-text-span');
      if (textSpan) textSpan.textContent = '更新中...';
      chrome.runtime.sendMessage({ type: 'FORCE_REFRESH_DATA' });
    });
  }

  document.querySelectorAll('.font-size-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const sizeKey = e.target.getAttribute('data-size');
      chrome.storage.local.set({ my_news_bar_font_size: sizeKey });
      newsBar.style.setProperty('--news-font-size', FONT_SIZES[sizeKey]);

      document.querySelectorAll('.font-size-btn').forEach(b => b.classList.remove('active'));
      e.target.classList.add('active');

      resetTimer();
    });
  });

  isInitialized = true;
}

function displayCurrentNews() {
  const span = document.getElementById('news-text-span');
  const area = document.querySelector('.news-content-area');
  if (!span || !area || newsList.length === 0) return;

  span.classList.add('news-fade-out');
  setTimeout(() => {
    const item = newsList[currentIndex];
    span.innerHTML = `<a href="${item.link}" target="_blank" rel="noopener noreferrer">${item.title}</a>`;
    span.classList.remove('news-fade-out');
    span.classList.remove('news-marquee');
    span.style.removeProperty('--scroll-amount');

    requestAnimationFrame(() => {
      const textWidth = span.offsetWidth;
      const areaWidth = area.offsetWidth;

      if (textWidth > areaWidth) {
        const diff = textWidth - areaWidth + 30;
        span.style.setProperty('--scroll-amount', `-${diff}px`);
        const duration = Math.max(diff / 40, 6);
        span.style.animationDuration = `${duration}s`;
        span.classList.add('news-marquee');
      }
    });
  }, 300);
}

function autoSlide() {
  if (newsList.length <= 1) return;
  currentIndex = (currentIndex + 1) % newsList.length;
  displayCurrentNews();
}

function resetTimer() {
  if (timer) clearInterval(timer);
  if (newsList.length > 1) {
    timer = setInterval(autoSlide, 30000);
  }
}

// ストレージからキャッシュデータを読み込んで画面に反映する
async function loadBarData() {
  if (!isInitialized) {
    initUI();
  }

  try {
    const data = await chrome.storage.local.get({
      my_news_bar_source: 'domestic',
      my_news_bar_hidden: 'false',
      my_news_bar_font_size: 'medium',
      my_news_bar_align: 'left',
      my_news_bar_theme: 'normal',
      my_news_bar_btn_left: '',
      my_news_bar_btn_top: '',
      cachedNews: [],
      cachedWeather: { title: '【天気】 読み込み中...', link: 'https://www.jma.go.jp/bosai/forecast/' }
    });

    // --- 【ここに直接指定したいサイトと文言を書く】 ---
    const currentUrl = window.location.href;
    let activeNewsList = data.cachedNews;

    if (currentUrl.includes('sites.google.com/view/arm32bit')) {
      activeNewsList = [{ title: ' 使ってくれてありがとう！/Thank You For Using!', link: '#' }];
    } else if (currentUrl.includes('youtube.com/@arm32bit')) {
      activeNewsList = [{ title: ' お、YouTubeみてくれるんだ～', link: '#' }];
    }
    // ------------------------------------------------

    // 保存されたボタン位置の復元
    if (showBtn && data.my_news_bar_btn_left && data.my_news_bar_btn_top) {
      showBtn.style.right = 'auto';
      showBtn.style.top = data.my_news_bar_btn_top;
      showBtn.style.left = data.my_news_bar_btn_left;
    }

    newsBar.style.setProperty('--news-font-size', FONT_SIZES[data.my_news_bar_font_size] || '14px');
    newsBar.style.setProperty('--news-align', data.my_news_bar_align);
    applyTheme(data.my_news_bar_theme);

    const prefixLabel = document.getElementById('news-prefix-label');
    if (prefixLabel) {
      if (data.my_news_bar_source === 'stocks') prefixLabel.textContent = '為替';
      else prefixLabel.textContent = '速報';
    }

    document.querySelectorAll('.font-size-btn').forEach(btn => {
      if (btn.getAttribute('data-size') === data.my_news_bar_font_size) {
        btn.classList.add('active');
      } else {
        btn.classList.remove('active');
      }
    });

    updateBarVisibility(data.my_news_bar_hidden === 'true');

    // 天気の反映
    const weatherSpan = document.getElementById('weather-text-span');
    if (weatherSpan && data.cachedWeather) {
      weatherSpan.innerHTML = `<a href="${data.cachedWeather.link}" target="_blank" rel="noopener noreferrer">${data.cachedWeather.title}</a>`;
    }

    // ニュース（または指定した専用文言）の反映
    newsList = activeNewsList;
    if (newsList.length === 0) {
      newsList = [{ title: 'データを読み込み中...', link: '#' }];
    }
    currentIndex = 0;
    displayCurrentNews();
    resetTimer();

  } catch (error) {
    console.error('データの表示に失敗しました:', error);
  }
}

// バックグラウンドやポップアップからの変更通知を受け取る
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'UPDATE_NEWS_SOURCE' || message.type === 'UPDATE_WEATHER_REGION' || message.type === 'DATA_UPDATED') {
    loadBarData();
  } else if (message.type === 'UPDATE_NEWS_ALIGN') {
    if (newsBar) {
      newsBar.style.setProperty('--news-align', message.align);
    }
  } else if (message.type === 'UPDATE_NEWS_THEME') {
    applyTheme(message.theme);
  }
});

// 初回読み込み
loadBarData();