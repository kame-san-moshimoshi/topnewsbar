document.addEventListener('DOMContentLoaded', () => {
  const selectElem = document.getElementById('news-source-select');
  const regionElem = document.getElementById('weather-region-select');
  const alignElem = document.getElementById('news-align-select');
  const themeElem = document.getElementById('news-theme-select');
  const scrollElem = document.getElementById('news-scroll-select');
  const statusMsg = document.getElementById('status-msg');

  // 保存されている設定値を読み込んで反映
  chrome.storage.local.get({ 
    my_news_bar_source: 'domestic',
    my_news_bar_region: '130000',
    my_news_bar_align: 'left',
    my_news_bar_theme: 'normal',
    my_news_bar_scroll: 'on'
  }, (data) => {
    selectElem.value = data.my_news_bar_source;
    regionElem.value = data.my_news_bar_region;
    alignElem.value = data.my_news_bar_align;
    themeElem.value = data.my_news_bar_theme;
    scrollElem.value = data.my_news_bar_scroll;
  });

  // コンテンツ（ニュース・為替など）の変更
  selectElem.addEventListener('change', (e) => {
    const selectedValue = e.target.value;
    chrome.storage.local.set({ my_news_bar_source: selectedValue }, () => {
      showStatus();
      // バックグラウンドにデータの強制再取得を依頼
      chrome.runtime.sendMessage({ type: 'FORCE_REFRESH_DATA' });
    });
  });

  // 天気地域の変更
  regionElem.addEventListener('change', (e) => {
    const selectedRegion = e.target.value;
    chrome.storage.local.set({ my_news_bar_region: selectedRegion }, () => {
      showStatus();
      // バックグラウンドにデータの強制再取得を依頼（天気も含まれるため）
      chrome.runtime.sendMessage({ type: 'FORCE_REFRESH_DATA' });
    });
  });

  // テキスト配置の変更
  alignElem.addEventListener('change', (e) => {
    const selectedAlign = e.target.value;
    chrome.storage.local.set({ my_news_bar_align: selectedAlign }, () => {
      showStatus();
      broadcastToTabs({ type: 'UPDATE_NEWS_ALIGN', align: selectedAlign });
    });
  });

  // デザインテーマの変更
  themeElem.addEventListener('change', (e) => {
    const selectedTheme = e.target.value;
    chrome.storage.local.set({ my_news_bar_theme: selectedTheme }, () => {
      showStatus();
      broadcastToTabs({ type: 'UPDATE_NEWS_THEME', theme: selectedTheme });
    });
  });

  // スクロールの変更
  scrollElem.addEventListener('change', (e) => {
    const selectedScroll = e.target.value;
    chrome.storage.local.set({ my_news_bar_scroll: selectedScroll }, () => {
      showStatus();
      broadcastToTabs({ type: 'UPDATE_NEWS_SCROLL', scroll: selectedScroll });
    });
  });

  // 保存完了メッセージの表示
  function showStatus() {
    statusMsg.textContent = '保存しました！';
    setTimeout(() => {
      statusMsg.textContent = '';
    }, 1500);
  }

  // 開いているすべてのタブにメッセージをブロードキャストする補助関数
  function broadcastToTabs(message) {
    chrome.tabs.query({}, (tabs) => {
      tabs.forEach((tab) => {
        if (tab.id) {
          chrome.tabs.sendMessage(tab.id, message).catch(() => {});
        }
      });
    });
  }
});